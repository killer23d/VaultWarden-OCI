# VaultWarden-OCI email security diagnostic

- Repository: `/workspaces/VaultWarden-OCI`
- Branch: `fix/production-readiness-handoffs`
- HEAD: `fcadd67e37a2857289cd7a09bfa318a502a7e45b`
- Generated UTC: `20260724T232850Z`
- Repository mutation: none
- Test execution: detached worktree at committed HEAD

## Focus

The security suite reports that the attachment helper does not enforce
the 16-character minimum through the shared password helper. This bundle
captures the exact assertion, matching tracked helpers, and execution trace.

## Non-zero diagnostic commands

- `version-shellcheck.log`
- `shellcheck-case-email.log`
- `case-email-normal.log`
- `case-email-trace.log`
- `security-suite.log`

## Important files

- `case-email-context.txt`: numbered context around the failed contract
- `case-email-full-numbered.txt`: complete numbered test source
- `contract-search.txt`: exact repository searches
- `tracked-source/`: matching tracked source files only
- `case-email-normal.log`: direct test execution
- `case-email-trace.log`: sanitized Bash execution trace
- `security-suite.log`: complete security suite result
