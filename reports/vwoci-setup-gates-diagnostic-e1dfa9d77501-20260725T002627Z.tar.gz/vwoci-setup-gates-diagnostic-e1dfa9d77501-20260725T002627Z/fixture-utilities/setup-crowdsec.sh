#!/usr/bin/env bash
set -euo pipefail
name="$(basename "$0")"
printf '%s:%s\n' "$name" "$*" >> "${VW_TEST_INVOCATION_LOG:?}"
case "$name" in
  setup-firewall.sh)
    if [[ " $* " == *" --phase ufw "* && "${VW_TEST_FAIL_UFW:-0}" == "1" ]]; then
      exit 42
    fi
    ;;
  setup-secrets.sh)
    if [[ "${1:-}" == "configure" && "${VW_TEST_FAIL_SECRETS:-0}" == "1" ]]; then
      exit 43
    fi
    ;;
esac
exit 0
