# VaultWarden-OCI setup-gates diagnostic

- Original repository: `/workspaces/VaultWarden-OCI`
- Branch: `fix/production-readiness-handoffs`
- Committed HEAD tested: `e1dfa9d77501cd4e41a82dcbd61d705d2fca3835`
- Generated: `20260725T002627Z`
- Test: `tests/suites/security/case-production-readiness-setup-gates.bash`

## Purpose

This bundle is read-only. It reproduces the failing UFW setup-gate assertion in a detached worktree and records the exact setup output, invocation ordering, Bash trace, phase-related source, and surrounding security-suite status.

## Key files

- `20-instrumented-case.txt`: exact captured UFW output and invocation log.
- `21-invocations.log`: utility execution order, when retained by the fixture.
- `02-setup-phase-context.txt`: production phase/error-reporting implementation.
- `03-test-assertion-context.txt`: current test fixture and assertions.
- `11-baseline-case-bash-x.txt`: full shell trace.
- `30-security-suite.txt`: surrounding suite result.

No `.env`, secret store, recovery handoff, or private-key content is included.
