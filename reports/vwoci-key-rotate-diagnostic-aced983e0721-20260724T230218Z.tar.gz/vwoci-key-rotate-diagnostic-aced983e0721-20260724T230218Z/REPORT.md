# Key-rotate fixture diagnostic

- Repository: `/workspaces/VaultWarden-OCI`
- Branch: `fix/production-readiness-handoffs`
- HEAD: `aced983e0721ef4dbf66a95bd9b648d5de2680bb`
- Working tree dirty: `no`

## Purpose

Capture the exact full-entrypoint fixture construction and the failure path involving `lib/setup-credentials.sh` before another patch is attempted.

## Most useful files

- `case-secrets-enclosing-functions.txt`
- `case-secrets-context.txt`
- `case-secrets-trace-focused.log`
- `case-secrets-trace.log`
- `relevant-working-tree-diff.patch`

This bundle intentionally excludes `.env`, encrypted secret stores, recovery handoffs, and private-key material.
