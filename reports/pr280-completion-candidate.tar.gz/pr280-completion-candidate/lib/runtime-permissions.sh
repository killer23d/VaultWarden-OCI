#!/usr/bin/env bash
# lib/runtime-permissions.sh — Validation and repair of explicit runtime trees.
# shellcheck shell=bash

_vw_runtime_numeric_id() { [[ "${1:-}" =~ ^[0-9]+$ ]]; }
_vw_runtime_safe_type() {
    local path="$1" expected="$2" label="$3"
    [[ ! -L "$path" ]] || { log_error "$label is a symlink: $path"; return 1; }
    [[ -e "$path" ]] || { log_error "$label is missing: $path"; return 1; }
    case "$expected" in
        directory) [[ -d "$path" ]] || { log_error "$label must be a directory: $path"; return 1; } ;;
        file) [[ -f "$path" ]] || { log_error "$label must be a regular file: $path"; return 1; } ;;
        *) return 2 ;;
    esac
}

_vw_runtime_tree_shape() {
    local path="$1" label="$2" invalid
    _vw_runtime_safe_type "$path" directory "$label" || return 1
    if ! invalid="$(find "$path" -xdev \( -type l -o \( ! -type d ! -type f \) \) -print -quit 2>/dev/null)"; then
        log_error "Could not inspect node types for $label: $path"
        return 1
    fi
    [[ -z "$invalid" ]] || { log_error "$label contains an unsupported node: $invalid"; return 1; }
}

_vw_runtime_tree_matches() {
    local path="$1" uid="$2" gid="$3" dir_mode="$4" file_mode="$5" label="$6" mismatch
    _vw_runtime_tree_shape "$path" "$label" || return 1
    if ! mismatch="$(find "$path" -xdev \
        \( -type d \( ! -uid "$uid" -o ! -gid "$gid" -o ! -perm "$dir_mode" \) \
        -o -type f \( ! -uid "$uid" -o ! -gid "$gid" -o ! -perm "$file_mode" \) \) \
        -print -quit 2>/dev/null)"; then
        log_error "Could not inspect permission metadata for $label: $path"
        return 1
    fi
    [[ -z "$mismatch" ]] || {
        log_error "$label permission drift detected at: $mismatch"
        log_error "Expected directories ${uid}:${gid} ${dir_mode}; files ${uid}:${gid} ${file_mode}."
        return 1
    }
}

_vw_runtime_repair_tree() {
    local path="$1" uid="$2" gid="$3" dir_mode="$4" file_mode="$5" label="$6"
    _vw_runtime_tree_shape "$path" "$label" || return 1
    find "$path" -xdev \( -type d -o -type f \) -exec chown "${uid}:${gid}" -- {} + || {
        log_error "Could not set ownership for $label: $path"
        return 1
    }
    find "$path" -xdev -type d -exec chmod "$dir_mode" -- {} + || {
        log_error "Could not set directory modes for $label: $path"
        return 1
    }
    find "$path" -xdev -type f -exec chmod "$file_mode" -- {} + || {
        log_error "Could not set file modes for $label: $path"
        return 1
    }
    _vw_runtime_tree_matches "$path" "$uid" "$gid" "$dir_mode" "$file_mode" "$label"
}

_vw_runtime_ids_from_config() {
    local puid="${1:-${PUID:-}}" pgid="${2:-${PGID:-}}"
    [[ -n "$puid" ]] || puid="$(get_config_value PUID "" 2>/dev/null || true)"
    [[ -n "$pgid" ]] || pgid="$(get_config_value PGID "" 2>/dev/null || true)"
    _vw_runtime_numeric_id "$puid" && _vw_runtime_numeric_id "$pgid" || {
        log_error "PUID and PGID must be numeric."
        return 1
    }
    printf '%s:%s\n' "$puid" "$pgid"
}

validate_runtime_state_permissions() {
    local state_dir="${1:-${PROJECT_STATE_DIR:-/var/lib/vaultwarden}}" ids puid pgid status=0
    ids="$(_vw_runtime_ids_from_config "${2:-}" "${3:-}")" || return 1
    puid="${ids%%:*}"; pgid="${ids#*:}"
    _vw_runtime_tree_matches "$state_dir/data" "$puid" "$pgid" 750 640 "Vaultwarden data" || status=1
    _vw_runtime_tree_matches "$state_dir/logs/vaultwarden" "$puid" "$pgid" 750 640 "Vaultwarden logs" || status=1
    _vw_runtime_tree_matches "$state_dir/logs/postfix" "$puid" "$pgid" 750 640 "Postfix logs" || status=1
    _vw_runtime_tree_matches "$state_dir/caddy/data" 2000 2000 750 600 "Caddy runtime data" || status=1
    _vw_runtime_tree_matches "$state_dir/caddy/config" 2000 2000 750 600 "Caddy runtime config" || status=1
    _vw_runtime_tree_matches "$state_dir/logs/caddy" 2000 2000 750 640 "Caddy logs" || status=1
    return "$status"
}

repair_runtime_state_permissions() {
    local state_dir="${1:-${PROJECT_STATE_DIR:-/var/lib/vaultwarden}}" ids puid pgid status=0 path
    (( EUID == 0 )) || { log_error "Runtime permission repair requires root."; return 1; }
    [[ ! -L "$state_dir" ]] || { log_error "PROJECT_STATE_DIR is a symlink: $state_dir"; return 1; }
    if [[ -e "$state_dir" && ! -d "$state_dir" ]]; then
        log_error "PROJECT_STATE_DIR must be a directory: $state_dir"
        return 1
    fi
    ids="$(_vw_runtime_ids_from_config "${2:-}" "${3:-}")" || return 1
    puid="${ids%%:*}"; pgid="${ids#*:}"

    local -a dirs=(
        "$state_dir/config" "$state_dir/secrets" "$state_dir/data"
        "$state_dir/logs/vaultwarden" "$state_dir/logs/postfix" "$state_dir/logs/caddy"
        "$state_dir/caddy/data" "$state_dir/caddy/config"
    )
    local -a files=(
        "$state_dir/logs/caddy/access.log" "$state_dir/logs/caddy/security.log"
    )
    for path in "${dirs[@]}"; do
        [[ ! -L "$path" ]] || { log_error "Managed directory is a symlink: $path"; return 1; }
        [[ ! -e "$path" || -d "$path" ]] || { log_error "Managed directory has the wrong type: $path"; return 1; }
    done
    for path in "${files[@]}"; do
        [[ ! -L "$path" ]] || { log_error "Managed file is a symlink: $path"; return 1; }
        [[ ! -e "$path" || -f "$path" ]] || { log_error "Managed file has the wrong type: $path"; return 1; }
    done

    local legacy_sentinel="$state_dir/data/.permissions-initialized"
    if [[ -L "$legacy_sentinel" || ( -e "$legacy_sentinel" && ! -f "$legacy_sentinel" ) ]]; then
        log_error "Legacy permission sentinel has an unsafe type: $legacy_sentinel"
        return 1
    fi
    if [[ -f "$legacy_sentinel" ]]; then
        rm -f -- "$legacy_sentinel" || {
            log_error "Could not remove legacy permission sentinel: $legacy_sentinel"
            return 1
        }
        [[ ! -e "$legacy_sentinel" && ! -L "$legacy_sentinel" ]] || return 1
        log_info "Removed restored init-permissions sentinel: $legacy_sentinel"
    fi

    install -d -m 700 -o root -g root "$state_dir/config" "$state_dir/secrets" || return 1
    install -d -m 750 -o "$puid" -g "$pgid" \
        "$state_dir/data" "$state_dir/logs/vaultwarden" "$state_dir/logs/postfix" || return 1
    install -d -m 750 -o 2000 -g 2000 \
        "$state_dir/caddy/data" "$state_dir/caddy/config" "$state_dir/logs/caddy" || return 1
    for path in "$state_dir/logs/caddy/access.log" "$state_dir/logs/caddy/security.log"; do
        if [[ ! -e "$path" ]]; then
            install -m 640 -o 2000 -g 2000 /dev/null "$path" || return 1
        fi
    done

    _vw_runtime_repair_tree "$state_dir/data" "$puid" "$pgid" 750 640 "Vaultwarden data" || status=1
    _vw_runtime_repair_tree "$state_dir/logs/vaultwarden" "$puid" "$pgid" 750 640 "Vaultwarden logs" || status=1
    _vw_runtime_repair_tree "$state_dir/logs/postfix" "$puid" "$pgid" 750 640 "Postfix logs" || status=1
    _vw_runtime_repair_tree "$state_dir/caddy/data" 2000 2000 750 600 "Caddy runtime data" || status=1
    _vw_runtime_repair_tree "$state_dir/caddy/config" 2000 2000 750 600 "Caddy runtime config" || status=1
    _vw_runtime_repair_tree "$state_dir/logs/caddy" 2000 2000 750 640 "Caddy logs" || status=1

    (( status == 0 )) || return 1
    validate_runtime_state_permissions "$state_dir" "$puid" "$pgid"
}
