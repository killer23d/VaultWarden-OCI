#!/usr/bin/env bash
# Consolidated permissions regression suite.
set -euo pipefail
# shellcheck source=../../lib/test-root.bash
source "$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)/lib/test-root.bash"
ROOT="${VW_TEST_REPO_ROOT:?VW_TEST_REPO_ROOT was not initialized}"

fail(){ printf 'FAIL permissions: %s\n' "$*" >&2; exit 1; }
pass(){ printf 'PASS: %s\n' "$*"; }

check_static_permission_contracts() (
  set -euo pipefail
  cd "$ROOT"

  grep -Fq 'chmod 0644 "$dest"' utilities/setup-secrets.sh \
    || fail '_ss_write_policy_file does not keep .sops.yaml at 0644'
  grep -Fq 'chmod 600 "$age_key_file"' utilities/setup-secrets.sh \
    || fail 'repository Age key is not kept at 0600'
  grep -Fq 'install -m 600 -o root -g root "$age_key_file" "$canonical_key"' utilities/setup-secrets.sh \
    || fail 'installed Age key is not root:root 0600'
  grep -Fq 'install -d -m 700 -o root -g root "/run/vaultwarden-oci/secrets"' utilities/setup-secrets.sh \
    || fail 'runtime secrets directory is not root:root 0700'

  ! grep -Fq 'find "${project_state_dir}" -type d -exec chmod 750 {} +' utilities/setup-storage.sh \
    || fail 'storage setup still broad-chmods all state directories'
  ! grep -Fq 'find "${project_state_dir}" -type f -exec chmod 640 {} +' utilities/setup-storage.sh \
    || fail 'storage setup still broad-chmods all state files'
  grep -Fq 'Never broad-chmod' utilities/setup-storage.sh \
    || fail 'storage setup lacks its sensitive-state guard'

  grep -Fq 'validate_runtime_state_permissions()' lib/runtime-permissions.sh \
    || fail 'runtime permission library lacks validation owner'
  grep -Fq 'repair_runtime_state_permissions()' lib/runtime-permissions.sh \
    || fail 'runtime permission library lacks repair owner'
  grep -Fq 'find "$path" -xdev' lib/runtime-permissions.sh \
    || fail 'runtime traversal is not constrained to the selected filesystem'
  ! grep -Fq 'chown -R' lib/runtime-permissions.sh \
    || fail 'runtime permission repair still uses broad chown -R'
  grep -Fq 'unsupported node' lib/runtime-permissions.sh \
    || fail 'runtime permission validation lacks unsupported-node rejection'

  grep -Fq '_vw_runtime_tree_matches "$state_dir/caddy/data" 2000 2000 750 600' lib/runtime-permissions.sh \
    || fail 'Caddy private runtime data files are not validated as owner-only 0600'
  grep -Fq '_vw_runtime_tree_matches "$state_dir/logs/caddy" 2000 2000 750 640' lib/runtime-permissions.sh \
    || fail 'Caddy logs are not kept at the separate 0640 log contract'

  grep -Fq 'source "${PROJECT_ROOT}/lib/defaults.sh"' utilities/repair-permissions.sh \
    || fail 'permission owner does not load canonical PUID/PGID defaults'
  grep -Fq 'validate_runtime_state_permissions "$PROJECT_STATE_DIR"' utilities/repair-permissions.sh \
    || fail 'permission --check does not validate runtime trees'
  grep -Fq 'repair_runtime_state_permissions "$PROJECT_STATE_DIR"' utilities/repair-permissions.sh \
    || fail 'permission repair does not use the runtime-tree owner'
  grep -Fq 'Runtime secret has unsupported type' utilities/repair-permissions.sh \
    || fail 'runtime secret inventory does not reject unsupported nodes'

  ! grep -Fq 'init-permissions:' docker-compose.yml.example \
    || fail 'ordinary Compose still contains the mutating permission-init service'
  ! grep -Fq 'condition: service_completed_successfully' docker-compose.yml.example \
    || fail 'a runtime service still depends on the removed permission mutator'
  grep -Fq 'image: vaultwarden-oci-caddy' docker-compose.yml.example \
    || fail 'the locally built Caddy image lacks a stable explicit image name'

  grep -Fq '_source_lib "lib/runtime-permissions.sh"' utilities/restore-run.sh \
    || fail 'restore-run does not source runtime permission helpers'
  grep -Fq 'repair_runtime_state_permissions "$STATE_DIR" "$PUID" "$PGID"' utilities/restore-run.sh \
    || fail 'restore-run no longer repairs restored runtime state'
  grep -Fq '_check_caddy_storage_permissions' utilities/maintenance-health.sh \
    || fail 'health no longer detects Caddy storage drift'

  pass 'static permission ownership boundaries are explicit and non-mutating at startup'
)

check_runtime_tree_behavior() (
  set -euo pipefail
  local tmp tree uid gid bad out
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  tree="$tmp/tree"
  uid="$(id -u)"; gid="$(id -g)"
  mkdir -p "$tree/nested"
  printf 'data\n' > "$tree/nested/item"
  chmod 750 "$tree" "$tree/nested"
  chmod 640 "$tree/nested/item"

  log_error(){ printf 'ERROR %s\n' "$*" >&2; }
  get_config_value(){ printf '%s' "${2:-}"; }
  # shellcheck source=../../../lib/runtime-permissions.sh
  source "$ROOT/lib/runtime-permissions.sh"

  _vw_runtime_tree_matches "$tree" "$uid" "$gid" 750 640 fixture \
    || fail 'valid runtime tree did not pass validation'

  chmod 600 "$tree/nested/item"
  if _vw_runtime_tree_matches "$tree" "$uid" "$gid" 750 640 fixture >/dev/null 2>&1; then
    fail 'mode drift passed runtime validation'
  fi
  chmod 640 "$tree/nested/item"

  mkfifo "$tree/bad-fifo"
  if _vw_runtime_tree_shape "$tree" fixture >/dev/null 2>&1; then
    fail 'FIFO passed runtime node-type validation'
  fi
  rm -f "$tree/bad-fifo"
  ln -s "$tree/nested/item" "$tree/bad-link"
  if _vw_runtime_tree_shape "$tree" fixture >/dev/null 2>&1; then
    fail 'symlink passed runtime node-type validation'
  fi
  rm -f "$tree/bad-link"

  mkdir -p "$tmp/fail-bin"
  cat > "$tmp/fail-bin/chown" <<'EOF_CHOWN'
#!/usr/bin/env bash
exit 41
EOF_CHOWN
  chmod +x "$tmp/fail-bin/chown"
  if PATH="$tmp/fail-bin:$PATH" _vw_runtime_repair_tree "$tree" "$uid" "$gid" 750 640 fixture >/dev/null 2>&1; then
    fail 'chown failure was hidden by runtime repair'
  fi

  cat > "$tmp/fail-bin/find" <<'EOF_FIND'
#!/usr/bin/env bash
exit 42
EOF_FIND
  chmod +x "$tmp/fail-bin/find"
  if PATH="$tmp/fail-bin:$PATH" _vw_runtime_tree_shape "$tree" fixture >/dev/null 2>&1; then
    fail 'find inspection failure was treated as a clean tree'
  fi

  pass 'runtime permission validation rejects drift, unsafe node types, and command failures'
)

check_common_permission_contract() (
  set -euo pipefail
  local tmp state repo target output rc
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  state="$tmp/state"; repo="$tmp/repo"
  mkdir -p "$state/config" "$state/secrets" "$repo/secrets/keys"
  PROJECT_STATE_DIR="$state"
  PROJECT_ROOT="$repo"
  SUDO_USER="$(id -un)"
  SUDO_GID="$(id -g)"
  export PROJECT_STATE_DIR PROJECT_ROOT SUDO_USER SUDO_GID
  # shellcheck source=../../../lib/log.sh
  source "$ROOT/lib/log.sh"
  # shellcheck source=../../../lib/common.sh
  source "$ROOT/lib/common.sh"

  [[ "$(expected_owner_for_path /etc/vaultwarden/age-key.txt)" == root ]] \
    || fail 'installed Age key owner is not root'
  [[ "$(expected_mode_for_path /etc/vaultwarden/age-key.txt)" == 600 ]] \
    || fail 'installed Age key mode is not 0600'
  [[ "$(expected_mode_for_path "$repo/.sops.yaml")" == 644 ]] \
    || fail '.sops.yaml mode is not 0644'
  [[ "$(expected_owner_for_path "$state/secrets/secrets.yaml")" == root ]] \
    || fail 'persistent secrets owner is not root'
  [[ "$(expected_mode_for_path "$state/secrets")" == 700 ]] \
    || fail 'persistent secrets directory mode is not 0700'
  [[ "$(expected_mode_for_path /run/vaultwarden-oci/secrets/example)" == 444 ]] \
    || fail 'runtime Docker secret mode is not 0444'

  target="$state/config/install.env"
  : > "$target"
  chmod 600 "$target"
  set +e
  output="$((
    _common_stat_owner(){ printf wrong; }
    _common_stat_group(){ printf wrong; }
    _common_stat_mode(){ printf 600; }
    chown(){ return 41; }
    fix_known_path_permissions "$target"
  ) 2>&1)"
  rc=$?
  set -e
  [[ "$rc" -ne 0 ]] || fail 'required ownership failure was swallowed'
  [[ "$output" != *'corrected and verified'* ]] \
    || fail 'failed ownership repair printed a success message'

  set +e
  (
    _common_stat_owner(){ printf root; }
    _common_stat_group(){ printf root; }
    _common_stat_mode(){ printf 644; }
    chmod(){ return 42; }
    fix_known_path_permissions "$target"
  ) >/dev/null 2>&1
  rc=$?
  set -e
  [[ "$rc" -ne 0 ]] || fail 'required mode failure was swallowed'

  set +e
  (
    _common_stat_owner(){ printf wrong; }
    _common_stat_group(){ printf wrong; }
    _common_stat_mode(){ printf 644; }
    chown(){ return 0; }
    chmod(){ return 0; }
    fix_known_path_permissions "$target"
  ) >/dev/null 2>&1
  rc=$?
  set -e
  [[ "$rc" -ne 0 ]] || fail 'false repair postcondition unexpectedly succeeded'

  pass 'central permission contracts remain fail-closed and truthful'
)


check_public_permission_check_behavior() (
  set -euo pipefail
  local tmp original_present original_mode output rc
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  cd "$ROOT"
  original_present=false
  original_mode=""
  if [[ -e .sops.yaml ]]; then
    original_present=true
    cp -p .sops.yaml "$tmp/sops.yaml"
    original_mode="$(stat -c '%a' .sops.yaml)"
  fi
  cleanup_policy() {
    if [[ "$original_present" == true ]]; then
      cp -p "$tmp/sops.yaml" .sops.yaml
      chmod "$original_mode" .sops.yaml
    else
      rm -f .sops.yaml
    fi
  }
  trap 'cleanup_policy; rm -rf "$tmp"' EXIT
  cat > .sops.yaml <<'POLICY'
creation_rules:
  - path_regex: '.*\\.yaml$'
    age: age1qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq
POLICY
  chmod 0640 .sops.yaml
  set +e
  output="$(PROJECT_STATE_DIR="$tmp/missing-state" utilities/repair-permissions.sh --check 2>&1)"
  rc=$?
  set -e
  (( rc != 0 )) || fail 'public permission --check accepted known metadata drift'
  [[ "$output" == *'.sops.yaml'* && "$output" == *'sudo ./utilities/repair-permissions.sh'* ]] \
    || fail 'public permission --check lacks the drifting path and exact remediation command'
  pass 'public permission --check detects drift without repairing it'
)

check_caddy_log_permission_helper() (
  set -euo pipefail
  local tmp log_dir dry_dir relative_path
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  fail_local(){ fail "$*"; }
  log_error(){ :; }
  log_info(){ :; }
  log_success(){ :; }

  declare -A synthetic_owners=()
  local repair_calls=0 touch_calls=0
  _maybe_sudo() {
    local command_name="$1"
    shift
    case "$command_name" in
      chown)
        [[ "${1:-}" == 2000:2000 && $# -eq 2 ]] \
          || fail_local "unexpected Caddy chown invocation: $*"
        synthetic_owners["$2"]=2000:2000
        ((repair_calls += 1))
        ;;
      chmod)
        command chmod "$@" || return 1
        ((repair_calls += 1))
        ;;
      mkdir) command mkdir "$@" ;;
      touch)
        command touch "$@" || return 1
        ((touch_calls += 1))
        ;;
      *) fail_local "unexpected privileged command: $command_name" ;;
    esac
  }
  stat() {
    if [[ "${1:-}" == -c ]]; then
      local format="${2:-}" path="${3:-}"
      case "$format" in
        %u:%g) printf '%s\n' "${synthetic_owners[$path]:-1000:1000}" ;;
        %a) command stat -c '%a' "$path" ;;
        *) command stat "$@" ;;
      esac
    else
      command stat "$@"
    fi
  }

  unset VAULTWARDEN_STORAGE_LIB_LOADED
  export VW_LOG_LIB_LOADED=1 VAULTWARDEN_DEFAULTS_LOADED=1
  # shellcheck source=../../../lib/storage.sh
  source "$ROOT/lib/storage.sh"

  log_dir="$tmp/missing/caddy"
  ensure_caddy_log_permissions "$log_dir" \
    || fail_local 'Caddy permission helper failed for a missing log tree'
  [[ -d "$log_dir" && -f "$log_dir/access.log" && -f "$log_dir/security.log" ]] \
    || fail_local 'Caddy permission helper did not create its explicit log targets'
  [[ "$(command stat -c '%a' "$log_dir")" == 750 ]] \
    || fail_local 'Caddy log directory mode is not 0750'
  for log_file in "$log_dir/access.log" "$log_dir/security.log"; do
    [[ "$(command stat -c '%a' "$log_file")" == 640 ]] \
      || fail_local "$log_file mode is not 0640"
    [[ "${synthetic_owners[$log_file]:-}" == 2000:2000 ]] \
      || fail_local "$log_file ownership was not repaired"
  done
  [[ "${synthetic_owners[$log_dir]:-}" == 2000:2000 && "$touch_calls" -eq 2 ]] \
    || fail_local 'Caddy log ownership/create count is incorrect'

  command chmod 777 "$log_dir"
  command chmod 666 "$log_dir/access.log" "$log_dir/security.log"
  synthetic_owners["$log_dir"]=123:456
  synthetic_owners["$log_dir/access.log"]=123:456
  synthetic_owners["$log_dir/security.log"]=123:456
  repair_calls=0; touch_calls=0
  ensure_caddy_log_permissions "$log_dir" \
    || fail_local 'Caddy permission helper failed while repairing drift'
  [[ "$repair_calls" -eq 6 && "$touch_calls" -eq 0 ]] \
    || fail_local 'Caddy drift did not trigger exactly six repairs and zero touches'

  repair_calls=0; touch_calls=0
  ensure_caddy_log_permissions "$log_dir" \
    || fail_local 'idempotent Caddy permission validation failed'
  [[ "$repair_calls" -eq 0 && "$touch_calls" -eq 0 ]] \
    || fail_local 'idempotent Caddy validation repeated a mutation'

  dry_dir="$tmp/dry-run/caddy"
  DRY_RUN=true
  ensure_caddy_log_permissions "$dry_dir" \
    || fail_local 'Caddy permission dry-run failed'
  [[ ! -e "$dry_dir" ]] || fail_local 'Caddy permission dry-run changed the filesystem'
  DRY_RUN=false

  if ensure_caddy_log_permissions "" >/dev/null 2>&1; then
    fail_local 'Caddy permission helper accepted an empty path'
  fi
  relative_path="relative-caddy-${RANDOM}"
  if ensure_caddy_log_permissions "$relative_path" >/dev/null 2>&1; then
    fail_local 'Caddy permission helper accepted a relative path'
  fi
  [[ ! -e "$relative_path" ]] || fail_local 'relative Caddy path was created'
  pass 'Caddy log permission helper creates, repairs, and remains idempotent'
)

check_startup_permission_boundary() (
  set -euo pipefail
  local validation_line secret_line
  validation_line="$(awk '/validate_or_repair_permissions \\|\\| exit 1/{print NR; exit}' "$ROOT/startup.sh")"
  secret_line="$(awk '/prepare_docker_secrets \\|\\| exit 1/{print NR; exit}' "$ROOT/startup.sh")"
  [[ -n "$validation_line" && -n "$secret_line" && "$validation_line" -lt "$secret_line" ]] \
    || fail 'startup permission validation no longer precedes ephemeral secret/service mutation'
  grep -Fq 'sudo ./utilities/repair-permissions.sh' "$ROOT/startup.sh" \
    || fail 'startup permission failure lacks the exact repair command'
  grep -Fq 'sudo ./startup.sh --repair' "$ROOT/startup.sh" \
    || fail 'startup permission failure lacks the explicit repair-mode command'
  ! grep -Fq 'auto_fix_critical_permissions "$PROJECT_ROOT"' "$ROOT/startup.sh" \
    || fail 'ordinary startup still invokes automatic permission repair'
  pass 'startup validates permissions before mutation and never repairs them implicitly'
)

check_static_permission_contracts
check_public_permission_check_behavior
check_runtime_tree_behavior
check_common_permission_contract
check_caddy_log_permission_helper
check_startup_permission_boundary
printf 'PASS permissions suite\n'
