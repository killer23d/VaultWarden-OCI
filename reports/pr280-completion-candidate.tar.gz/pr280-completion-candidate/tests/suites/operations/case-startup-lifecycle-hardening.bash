#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=../../lib/test-root.bash
source "${SCRIPT_DIR}/../../lib/test-root.bash"
ROOT="${VW_TEST_REPO_ROOT:?VW_TEST_REPO_ROOT was not initialized}"

fail() { printf 'FAIL startup lifecycle hardening: %s\n' "$*" >&2; exit 1; }
assert_file_has() { grep -Fq -- "$2" "$1" || fail "missing '$2' in $1"; }
assert_file_lacks() { ! grep -Fq -- "$2" "$1" || fail "unexpected '$2' in $1"; }

extract_func() {
  local file="$1" func="$2"
  awk -v f="$func" '
    $0 ~ "^" f "\\(\\)" { capture=1 }
    capture {
      print
      opens=gsub(/\{/,"{")
      closes=gsub(/\}/,"}")
      depth += opens - closes
      if (depth == 0) exit
    }
  ' "$file"
}

run_age_key_regression() (
  set -euo pipefail
  local tmp
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  SCRIPT_DIR="$tmp/repo"
  mkdir -p "$SCRIPT_DIR/secrets/keys"
  printf 'synthetic repository key\n' > "$SCRIPT_DIR/secrets/keys/age-key.txt"
  SOPS_AGE_KEY_FILE="$tmp/rejected-configured-key.txt"
  DRY_RUN=false
  DOCKER_SECRETS_DIR="$tmp/runtime-secrets"
  LOG_FILE="$tmp/log"
  CALL_FILE="$tmp/key-health-calls"
  export SCRIPT_DIR SOPS_AGE_KEY_FILE DRY_RUN DOCKER_SECRETS_DIR LOG_FILE CALL_FILE
  log_info(){ printf 'INFO %s\n' "$*" >> "$LOG_FILE"; }
  log_warn(){ printf 'WARN %s\n' "$*" >> "$LOG_FILE"; }
  log_error(){ printf 'ERROR %s\n' "$*" >> "$LOG_FILE"; }
  log_success(){ printf 'SUCCESS %s\n' "$*" >> "$LOG_FILE"; }
  check_age_key_health(){
    printf '%s\n' "${1:-}" >> "$CALL_FILE"
    [[ "${1:-}" == "$SCRIPT_DIR/secrets/keys/age-key.txt" ]]
  }
  eval "$(extract_func "$ROOT/startup.sh" check_age_key_health_preflight)"
  if check_age_key_health_preflight; then
    fail "invalid configured Age key was replaced by a repository key"
  fi
  [[ "$SOPS_AGE_KEY_FILE" == "$tmp/rejected-configured-key.txt" ]] \
    || fail "failed key preflight changed the selected identity"
  [[ "$(wc -l < "$CALL_FILE" | tr -d ' ')" == 1 ]] \
    || fail "failed key preflight evaluated a fallback identity"

  check_age_key_health_preflight(){ return 1; }
  schema_validate(){ : > "$tmp/schema-called"; }
  validate_required_secrets(){ : > "$tmp/required-called"; }
  export_docker_secrets(){ : > "$tmp/export-called"; }
  SECRETS_FILE="$tmp/secrets.yaml"
  export SECRETS_FILE
  eval "$(extract_func "$ROOT/startup.sh" prepare_docker_secrets)"
  if prepare_docker_secrets; then
    fail "secret preparation succeeded after selected Age-key failure"
  fi
  [[ ! -e "$tmp/schema-called" && ! -e "$tmp/required-called" && ! -e "$tmp/export-called" ]] \
    || fail "secret mutation ran after selected Age-key failure"
)

make_fixture() {
  local repo="$1"
  mkdir -p "$repo/lib" "$repo/utilities" "$repo/caddy" "$repo/bin" "$repo/secrets/keys"
  cp "$ROOT/startup.sh" "$repo/startup.sh"
  cp "$ROOT/setup.sh" "$repo/setup.sh"
  chmod +x "$repo/startup.sh" "$repo/setup.sh"
  printf '1.0.0\n' > "$repo/VERSION"

  cat > "$repo/lib/log.sh" <<'STUB'
log_info(){ printf 'INFO %s\n' "$*"; }
log_warn(){ printf 'WARN %s\n' "$*"; }
log_error(){ printf 'ERROR %s\n' "$*" >&2; }
log_success(){ printf 'SUCCESS %s\n' "$*"; }
log_debug(){ :; }
log_hint(){ printf 'HINT %s\n' "$*"; }
log_header(){ printf 'HEADER %s\n' "$*"; }
log_phase(){ printf 'PHASE %s\n' "$*"; }
print_project_version(){ printf '%s test\n' "$1"; }
STUB
  cat > "$repo/lib/defaults.sh" <<'STUB'
_VW_DEFAULT_STATE_DIR="${VW_TEST_STATE_DIR:-/tmp/vw-test-state}"
_VW_DEFAULT_DATA_MOUNT="${VW_TEST_STATE_DIR:-/tmp/vw-test-state}"
_VW_DEFAULT_PUID=1001
_VW_DEFAULT_PGID=1001
_VW_DEFAULT_REQUIRED_COMMANDS=(docker python3 getent)
_VW_DEFAULT_CRITICAL_SERVICES=(vaultwarden caddy)
_VW_DEFAULT_LOG_SERVICES=(vaultwarden caddy postfix)
_VW_DEFAULT_EMAIL_MODES=(auto api smtp direct host)
STUB
  cat > "$repo/lib/config.sh" <<'STUB'
load_project_environment(){
  PROJECT_STATE_DIR="${VW_TEST_STATE_DIR:?}"
  SECRETS_FILE="$PROJECT_STATE_DIR/secrets/secrets.yaml"
  SOPS_AGE_KEY_FILE="${VW_TEST_REPO:?}/secrets/keys/age-key.txt"
  DOMAIN="vault.example.test"
  UPDATE_DNS=true
  PUID=1001; PGID=1001
  export PROJECT_STATE_DIR SECRETS_FILE SOPS_AGE_KEY_FILE DOMAIN UPDATE_DNS PUID PGID
}
get_config_value(){ printf '%s' "${2:-}"; }
_read_env_value(){ :; }
STUB
  cat > "$repo/lib/common.sh" <<'STUB'
init_common_lib(){ :; }
require_root(){ :; }
is_root(){ return 0; }
_require_script(){ [[ -x "$1" ]]; }
wait_for_entropy(){ return 0; }
press_enter_to_continue(){ return 0; }
STUB
  cat > "$repo/lib/docker.sh" <<'STUB'
check_docker_available(){ return 0; }
wait_for_service_ready(){ return 0; }
STUB
  cat > "$repo/lib/crypto.sh" <<'STUB'
check_age_key_health(){ return "${VW_TEST_KEY_RC:-0}"; }
resolve_age_key_path(){ printf '%s\n' "${VW_TEST_REPO:?}/secrets/keys/age-key.txt"; }
STUB
  cat > "$repo/lib/secrets.sh" <<'STUB'
schema_validate(){ return 0; }
validate_required_secrets(){ return 0; }
export_docker_secrets(){ printf 'secret-export\n' >> "${VW_TEST_LOG:?}"; }
prepare_push_secret_placeholders(){ printf 'push-placeholders\n' >> "${VW_TEST_LOG:?}"; }
secrets_file_exists(){ return 0; }
ensure_sops_env(){ return 0; }
check_placeholder_values(){ return 0; }
STUB
  cat > "$repo/lib/storage.sh" <<'STUB'
check_project_state_ready(){ return 0; }
_storage_validate_paths(){ return 0; }
STUB
  cat > "$repo/lib/runtime-permissions.sh" <<'STUB'
validate_runtime_state_permissions(){ return 0; }
STUB
  cat > "$repo/lib/validate.sh" <<'STUB'
validate_domain(){ [[ "$1" == *.* && "$1" != bad* ]]; }
validate_email(){ [[ "$1" == *@*.* ]]; }
STUB
  cat > "$repo/lib/operations.sh" <<'STUB'
operation_acquire(){ printf 'guard %s\n' "$*" >> "${VW_TEST_LOG:?}"; return "${VW_TEST_GUARD_RC:-0}"; }
operation_set_phase(){ printf 'phase %s\n' "$*" >> "${VW_TEST_LOG:?}"; }
operation_release(){ printf 'release %s\n' "$*" >> "${VW_TEST_LOG:?}"; }
STUB

  cat > "$repo/lib/backup-utils.sh" <<'STUB'
# setup fixture: no backup helpers required
STUB
  cat > "$repo/lib/setup-credentials.sh" <<'STUB'
publish_setup_credentials(){ printf '%s/setup-credentials.txt\n' "${VW_TEST_REPO:?}"; }
STUB

  cat > "$repo/utilities/repair-permissions.sh" <<'STUB'
#!/usr/bin/env bash
if [[ "${1:-}" == --check ]]; then
  printf 'permission-check\n' >> "${VW_TEST_LOG:?}"
  exit "${VW_TEST_PERMISSION_CHECK_RC:-0}"
fi
printf 'permission-repair\n' >> "${VW_TEST_LOG:?}"
exit "${VW_TEST_PERMISSION_REPAIR_RC:-0}"
STUB
  cat > "$repo/utilities/setup-firewall.sh" <<'STUB'
#!/usr/bin/env bash
if [[ "${VW_TEST_SETUP_RUN:-false}" == true ]]; then
  printf 'setup-phase %s %s\n' "${0##*/}" "$*" >> "${VW_TEST_LOG:?}"
  exit "${VW_TEST_SETUP_FIREWALL_RC:-0}"
fi
if [[ " $* " == *' --dry-run '* ]]; then
  printf 'nat-validate\n' >> "${VW_TEST_LOG:?}"
  if [[ "${VW_TEST_NAT_DRIFT:-false}" == true ]]; then
    printf '[DRY RUN] Would add: MASQUERADE for test subnet\n'
  else
    printf 'OK: MASQUERADE already present\n'
  fi
  exit "${VW_TEST_NAT_VALIDATE_RC:-0}"
fi
printf 'nat-repair\n' >> "${VW_TEST_LOG:?}"
exit "${VW_TEST_NAT_REPAIR_RC:-0}"
STUB
  cat > "$repo/utilities/maintenance-update-dns.sh" <<'STUB'
#!/usr/bin/env bash
printf 'dns-repair\n' >> "${VW_TEST_LOG:?}"
exit "${VW_TEST_DNS_REPAIR_RC:-0}"
STUB
  cat > "$repo/utilities/maintenance-health.sh" <<'STUB'
#!/usr/bin/env bash
printf 'health\n' >> "${VW_TEST_LOG:?}"
exit 0
STUB
  for file in setup-system.sh setup-storage.sh setup-env.sh setup-secrets.sh setup-systemd.sh setup-crowdsec.sh uninstall-vaultwarden.sh; do
    cat > "$repo/utilities/$file" <<'STUB'
#!/usr/bin/env bash
printf 'setup-phase %s %s\n' "${0##*/}" "$*" >> "${VW_TEST_LOG:?}"
exit "${VW_TEST_SETUP_PHASE_RC:-0}"
STUB
  done
  cat > "$repo/caddy/entrypoint.sh" <<'STUB'
#!/usr/bin/env sh
exit 0
STUB

  cat > "$repo/bin/getent" <<'STUB'
#!/usr/bin/env bash
printf 'getent %s\n' "$*" >> "${VW_TEST_LOG:?}"
case "${1:-}" in
  group) [[ "${VW_TEST_GROUP_EXISTS:-true}" == true ]] ;;
  ahosts|hosts) [[ "${VW_TEST_DNS_RESOLVES:-true}" == true ]] ;;
  *) exit 0 ;;
esac
STUB
  cat > "$repo/bin/groupadd" <<'STUB'
#!/usr/bin/env bash
printf 'groupadd %s\n' "$*" >> "${VW_TEST_LOG:?}"
exit "${VW_TEST_GROUPADD_RC:-0}"
STUB
  for command_name in chown chmod flock systemctl iptables apt-get install mktemp; do
    real_command="$(command -v "$command_name" 2>/dev/null || true)"
    cat > "$repo/bin/$command_name" <<STUB
#!/usr/bin/env bash
if [[ "\${VW_TEST_BLOCK_MUTATORS:-false}" == true ]]; then
  printf 'mutator %s %s\n' "$command_name" "\$*" >> "\${VW_TEST_LOG:?}"
  exit 98
fi
if [[ -n "$real_command" ]]; then
  exec "$real_command" "\$@"
fi
exit 127
STUB
  done
  cat > "$repo/bin/docker" <<'STUB'
#!/usr/bin/env bash
set -euo pipefail
printf 'docker %s\n' "$*" >> "${VW_TEST_LOG:?}"
case "$*" in
  'compose version') exit 0 ;;
  'compose config --quiet') exit 0 ;;
  'compose config --services')
    [[ "${VW_TEST_COMPOSE_SERVICES_RC:-0}" == 0 ]] || exit "${VW_TEST_COMPOSE_SERVICES_RC}"
    printf 'vaultwarden\ncaddy\npostfix\n'; exit 0 ;;
  'compose config --images')
    [[ "${VW_TEST_COMPOSE_IMAGES_RC:-0}" == 0 ]] || exit "${VW_TEST_COMPOSE_IMAGES_RC}"
    printf 'ghcr.io/dani-garcia/vaultwarden:1.36.0\nvaultwarden-oci-caddy\nboky/postfix:5.1.0\n'; exit 0 ;;
  'compose config --format json')
    if [[ "${VW_TEST_INVALID_COMPOSE_JSON:-false}" == true ]]; then printf '{invalid\n'; else
      printf '%s\n' '{"services":{"vaultwarden":{"image":"ghcr.io/dani-garcia/vaultwarden:1.36.0"},"caddy":{"image":"vaultwarden-oci-caddy","build":{"context":"./caddy"}},"postfix":{"image":"boky/postfix:5.1.0"}}}'
    fi
    exit 0 ;;
  'compose up --help') printf '%s\n' 'Usage: docker compose up [--pull POLICY] [--no-build]'; exit 0 ;;
  compose\ up\ -d\ --pull\ never\ --no-build*) exit "${VW_TEST_COMPOSE_UP_RC:-0}" ;;
  compose\ pull\ --quiet*) exit "${VW_TEST_PULL_RC:-0}" ;;
  compose\ build\ --pull*) exit "${VW_TEST_BUILD_RC:-0}" ;;
  'compose ps') exit 0 ;;
  'compose down') exit 0 ;;
  image\ inspect\ *)
    image="${*:3}"
    [[ "$image" == "${VW_TEST_MISSING_IMAGE:-__none__}" ]] && exit 1
    exit 0 ;;
  ps\ -aq\ --filter*)
    [[ "${VW_TEST_DOCKER_PS_RC:-0}" == 0 ]] || exit "${VW_TEST_DOCKER_PS_RC}"
    [[ "${VW_TEST_ORPHAN:-none}" == none || -e "${VW_TEST_REPO:?}/orphan-removed" ]] || printf 'deadbeef\n'
    exit 0 ;;
  inspect\ --format\ *com.docker.compose.service*deadbeef)
    [[ "${VW_TEST_DOCKER_INSPECT_RC:-0}" == 0 ]] || exit "${VW_TEST_DOCKER_INSPECT_RC}"
    printf 'old-sidecar\n'; exit 0 ;;
  inspect\ --format\ *State.Status*deadbeef)
    [[ "${VW_TEST_ORPHAN:-none}" == running ]] && printf 'running\n' || printf 'exited\n'
    exit 0 ;;
  inspect\ --format\ *Name*deadbeef) printf '/vaultwarden_old\n'; exit 0 ;;
  'rm -f -- deadbeef')
    [[ "${VW_TEST_ORPHAN_REPAIR_RC:-0}" == 0 ]] || exit "${VW_TEST_ORPHAN_REPAIR_RC}"
    : > "${VW_TEST_REPO:?}/orphan-removed"
    exit 0 ;;
  *) exit 0 ;;
esac
STUB
  chmod +x "$repo"/utilities/* "$repo"/caddy/entrypoint.sh "$repo"/bin/*

  mkdir -p \
    "$repo/state/data" "$repo/state/caddy/data" "$repo/state/caddy/config" \
    "$repo/state/logs/vaultwarden" "$repo/state/logs/caddy" "$repo/state/logs/postfix" \
    "$repo/state/secrets"
  : > "$repo/docker-compose.yml"
  printf 'key\n' > "$repo/secrets/keys/age-key.txt"
  printf 'secret\n' > "$repo/state/secrets/secrets.yaml"
}

run_startup() {
  local repo="$1" out="$2"
  shift 2
  local -a env_vars=() args=()
  while (($#)) && [[ "$1" != -- ]]; do env_vars+=("$1"); shift; done
  [[ "${1:-}" == -- ]] && shift
  args=("$@")
  : > "$repo/invocations.log"
  rm -f "$repo/orphan-removed"
  set +e
  (cd "$repo" && env PATH="$repo/bin:$PATH" \
    VW_TEST_REPO="$repo" VW_TEST_STATE_DIR="$repo/state" VW_TEST_LOG="$repo/invocations.log" \
    "${env_vars[@]}" "$repo/startup.sh" --background "${args[@]}") > "$out" 2>&1
  local rc=$?
  set -e
  return "$rc"
}

run_public_entrypoint_regressions() (
  set -euo pipefail
  local tmp repo out group_line guard_line impl_line perm_line rm_line nat_line dns_line up_line spec
  tmp="$(mktemp -d)"
  trap 'rm -rf "$tmp"' EXIT
  repo="$tmp/repo"
  make_fixture "$repo"

  for group_exists in false true; do
    : > "$repo/invocations.log"
    out="$tmp/setup-${group_exists}.out"
    env PATH="$repo/bin:$PATH" VW_TEST_REPO="$repo" VW_TEST_STATE_DIR="$repo/state" \
      VW_TEST_LOG="$repo/invocations.log" VW_TEST_GROUP_EXISTS="$group_exists" \
      VW_TEST_BLOCK_MUTATORS=true "$repo/setup.sh" install --domain vault.example.test --email admin@example.test --auto --dry-run > "$out" 2>&1 \
      || fail "valid setup dry-run failed with group=${group_exists}"
    assert_file_has "$out" 'VaultWarden-OCI Setup Preview'
    assert_file_has "$out" 'setup-system.sh --auto --dry-run'
    assert_file_has "$out" 'setup-firewall.sh --phase iptables --auto --dry-run'
    [[ ! -s "$repo/invocations.log" ]] || fail "setup dry-run invoked a mutator: $(cat "$repo/invocations.log")"
    ! find "$repo" -maxdepth 1 -type d -name 'vw_setup.*' -print -quit | grep -q . \
      || fail "setup dry-run created a sensitive workspace"
  done
  if env PATH="$repo/bin:$PATH" VW_TEST_REPO="$repo" VW_TEST_STATE_DIR="$repo/state" \
    VW_TEST_LOG="$repo/invocations.log" VW_TEST_BLOCK_MUTATORS=true \
    "$repo/setup.sh" install --domain bad --email admin@example.test --dry-run >/dev/null 2>&1; then
    fail 'invalid setup dry-run succeeded'
  fi

  : > "$repo/invocations.log"
  env PATH="$repo/bin:$PATH" VW_TEST_REPO="$repo" VW_TEST_STATE_DIR="$repo/state" \
    VW_TEST_LOG="$repo/invocations.log" VW_TEST_GROUP_EXISTS=false "$repo/setup.sh" \
    install --domain vault.example.test --email admin@example.test --auto >/dev/null 2>&1 \
    || fail 'real setup fixture failed'
  group_line="$(grep -n '^groupadd ' "$repo/invocations.log" | cut -d: -f1)"
  guard_line="$(grep -n '^guard ' "$repo/invocations.log" | head -1 | cut -d: -f1)"
  impl_line="$(grep -n '^setup-phase setup-system.sh ' "$repo/invocations.log" | head -1 | cut -d: -f1)"
  [[ -n "$group_line" && -n "$guard_line" && -n "$impl_line" && "$group_line" -lt "$guard_line" && "$guard_line" -lt "$impl_line" ]] \
    || fail "real setup ordering is wrong: $(cat "$repo/invocations.log")"
  assert_file_has "$repo/invocations.log" 'permission-repair'
  assert_file_has "$repo/invocations.log" 'docker compose pull --quiet'
  assert_file_has "$repo/invocations.log" 'docker compose build --pull caddy'

  : > "$repo/invocations.log"
  if env PATH="$repo/bin:$PATH" VW_TEST_REPO="$repo" VW_TEST_STATE_DIR="$repo/state" \
    VW_TEST_LOG="$repo/invocations.log" VW_TEST_GROUP_EXISTS=true VW_TEST_INVALID_COMPOSE_JSON=true \
    "$repo/setup.sh" install --domain vault.example.test --email admin@example.test --auto >/dev/null 2>&1; then
    fail 'real setup accepted an invalid Compose image inventory'
  fi

  out="$tmp/start-normal.out"
  run_startup "$repo" "$out" -- || fail "normal startup failed: $(cat "$out")"
  assert_file_has "$repo/invocations.log" 'permission-check'
  assert_file_has "$repo/invocations.log" 'nat-validate'
  assert_file_has "$repo/invocations.log" 'docker compose up -d --pull never --no-build'
  assert_file_lacks "$repo/invocations.log" 'permission-repair'
  assert_file_lacks "$repo/invocations.log" 'nat-repair'
  assert_file_lacks "$repo/invocations.log" 'dns-repair'
  assert_file_lacks "$repo/invocations.log" 'docker compose pull'
  assert_file_lacks "$repo/invocations.log" 'docker rm '
  assert_file_lacks "$repo/invocations.log" 'docker system prune'

  out="$tmp/start-permission.out"
  if run_startup "$repo" "$out" VW_TEST_PERMISSION_CHECK_RC=1 --; then fail 'permission drift did not block startup'; fi
  assert_file_has "$out" 'sudo ./utilities/repair-permissions.sh'
  assert_file_has "$out" 'sudo ./startup.sh --repair'
  assert_file_lacks "$repo/invocations.log" 'docker compose up -d'

  out="$tmp/start-orphan-stopped.out"
  run_startup "$repo" "$out" VW_TEST_ORPHAN=stopped -- \
    || fail "stopped managed orphan should warn without blocking: $(cat "$out")"
  assert_file_has "$out" 'Stopped managed Compose orphan remains untouched'
  assert_file_lacks "$repo/invocations.log" 'docker rm '

  out="$tmp/start-orphan.out"
  if run_startup "$repo" "$out" VW_TEST_ORPHAN=running --; then fail 'running managed orphan did not block startup'; fi
  assert_file_has "$out" 'sudo ./startup.sh --repair'
  assert_file_lacks "$repo/invocations.log" 'docker rm '

  out="$tmp/start-orphan-inventory.out"
  if run_startup "$repo" "$out" VW_TEST_DOCKER_PS_RC=44 --; then fail 'Docker project inventory failure was treated as no orphans'; fi
  assert_file_lacks "$repo/invocations.log" 'docker compose up -d'

  out="$tmp/start-orphan-inspect.out"
  if run_startup "$repo" "$out" VW_TEST_ORPHAN=running VW_TEST_DOCKER_INSPECT_RC=45 --; then fail 'managed orphan inspection failure was hidden'; fi
  assert_file_lacks "$repo/invocations.log" 'docker compose up -d'

  out="$tmp/start-nat.out"
  if run_startup "$repo" "$out" VW_TEST_NAT_DRIFT=true --; then fail 'NAT drift did not block startup'; fi
  assert_file_has "$out" 'sudo ./utilities/setup-firewall.sh --phase iptables --auto'
  assert_file_lacks "$repo/invocations.log" 'nat-repair'

  out="$tmp/start-dns.out"
  if run_startup "$repo" "$out" VW_TEST_DNS_RESOLVES=false --; then fail 'unresolved DNS did not block startup'; fi
  assert_file_has "$out" 'sudo ./utilities/maintenance-update-dns.sh update-dns'
  assert_file_lacks "$repo/invocations.log" 'dns-repair'

  out="$tmp/start-image-inventory.out"
  if run_startup "$repo" "$out" VW_TEST_COMPOSE_IMAGES_RC=46 --; then fail 'Compose image inventory failure was treated as an empty clean result'; fi
  assert_file_lacks "$repo/invocations.log" 'docker compose up -d'

  out="$tmp/start-image.out"
  if run_startup "$repo" "$out" VW_TEST_MISSING_IMAGE=vaultwarden-oci-caddy --; then fail 'missing local image did not block startup'; fi
  assert_file_has "$out" 'sudo ./utilities/maintenance-update.sh --images'
  assert_file_lacks "$repo/invocations.log" 'docker compose pull'

  out="$tmp/repair-ok.out"
  run_startup "$repo" "$out" VW_TEST_ORPHAN=running -- --repair || fail "repair startup failed: $(cat "$out")"
  perm_line="$(grep -n '^permission-repair' "$repo/invocations.log" | head -1 | cut -d: -f1)"
  rm_line="$(grep -n '^docker rm -f -- deadbeef' "$repo/invocations.log" | cut -d: -f1)"
  nat_line="$(grep -n '^nat-repair' "$repo/invocations.log" | cut -d: -f1)"
  dns_line="$(grep -n '^dns-repair' "$repo/invocations.log" | cut -d: -f1)"
  up_line="$(grep -n '^docker compose up -d ' "$repo/invocations.log" | cut -d: -f1)"
  [[ "$perm_line" -lt "$rm_line" && "$rm_line" -lt "$nat_line" && "$nat_line" -lt "$dns_line" && "$dns_line" -lt "$up_line" ]] \
    || fail "repair order is wrong: $(cat "$repo/invocations.log")"
  assert_file_has "$repo/invocations.log" 'guard --id startup --label Startup repair'
  assert_file_lacks "$repo/invocations.log" 'docker compose pull'
  assert_file_lacks "$repo/invocations.log" 'docker system prune'

  for spec in \
    'VW_TEST_PERMISSION_REPAIR_RC=1' \
    'VW_TEST_ORPHAN_REPAIR_RC=1 VW_TEST_ORPHAN=running' \
    'VW_TEST_NAT_REPAIR_RC=1' \
    'VW_TEST_DNS_REPAIR_RC=1'; do
    local -a envs=()
    read -r -a envs <<< "$spec"
    out="$tmp/repair-failure.out"
    if run_startup "$repo" "$out" "${envs[@]}" -- --repair; then fail "required repair failure succeeded: $spec"; fi
    assert_file_lacks "$repo/invocations.log" 'docker compose up -d'
  done

  printf 'PASS public setup dry-run and startup mutation boundaries\n'
)

run_age_key_regression
run_public_entrypoint_regressions

# Keep the existing readiness and Postfix health contracts visible.
grep -Fq 'wait_for_services || readiness_rc=$?' "$ROOT/startup.sh" \
  || fail 'critical readiness result is not preserved'
grep -Fq 'wait_for_optional_services || true' "$ROOT/startup.sh" \
  || fail 'optional Postfix readiness grace was removed'
postfix_health="$(awk '/postfix status/ {capture=1; remaining=7} capture && remaining>0 {print; remaining--}' "$ROOT/docker-compose.yml.example")"
[[ "$postfix_health" == *'interval: 15s'* && "$postfix_health" == *'timeout: 5s'* \
  && "$postfix_health" == *'retries: 4'* && "$postfix_health" == *'start_period: 20s'* ]] \
  || fail 'Postfix health timing contract changed'

bash -n "$ROOT/startup.sh" || fail 'startup.sh must pass Bash syntax validation'
printf 'PASS startup lifecycle hardening contracts\n'
