#!/usr/bin/env bash
# Validate or repair the explicit VaultWarden-OCI permission contract.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
source "${PROJECT_ROOT}/lib/log.sh"
source "${PROJECT_ROOT}/lib/defaults.sh"
source "${PROJECT_ROOT}/lib/config.sh"
source "${PROJECT_ROOT}/lib/common.sh"
source "${PROJECT_ROOT}/lib/operations.sh"
source "${PROJECT_ROOT}/lib/runtime-permissions.sh"
init_common_lib "$0"

MODE=repair
while (($#)); do
    case "$1" in
        --check|--dry-run) MODE=check; shift ;;
        --help|-h|help)
            cat <<'HELP'
VaultWarden-OCI permission validation and repair

USAGE:
  ./utilities/repair-permissions.sh --check
  sudo ./utilities/repair-permissions.sh

Repair is limited to explicit repository, installed-configuration, runtime-secret,
service-state, and service-log paths. Unsupported node types and failed
postconditions are fatal.
HELP
            exit 0 ;;
        --version|-V) print_project_version "VaultWarden-OCI" "$PROJECT_ROOT"; exit 0 ;;
        *) log_error "Unknown option: $1"; exit 2 ;;
    esac
done

OPERATION_HELD=false
runtime_secret_list=""
_permission_cleanup() {
    local rc=$? release_rc=0
    trap - EXIT HUP INT TERM
    [[ -z "$runtime_secret_list" ]] || rm -f -- "$runtime_secret_list"
    if [[ "$OPERATION_HELD" == true ]]; then
        operation_release "$rc" || release_rc=$?
        (( release_rc == 0 )) || rc=1
    fi
    exit "$rc"
}
trap _permission_cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' HUP TERM

if [[ "$MODE" == repair ]]; then
    (( EUID == 0 )) || { log_error "Permission repair requires root."; log_error "Run: sudo ./utilities/repair-permissions.sh"; exit 1; }
    operation_acquire --id permission-repair --label "Permission repair" \
        --specific-lock /run/lock/vaultwarden-permission-repair.lock || exit $?
    OPERATION_HELD=true
    operation_set_phase repair "Repairing explicit permission targets"
fi

load_project_environment >/dev/null 2>&1 || log_warn "Using default runtime paths because no project environment could be loaded."
PROJECT_STATE_DIR="${PROJECT_STATE_DIR:-/var/lib/vaultwarden}"
SECRETS_FILE="${SECRETS_FILE:-${PROJECT_STATE_DIR}/secrets/secrets.yaml}"
PUID="${PUID:-$(get_config_value PUID "${_VW_DEFAULT_PUID}" 2>/dev/null || printf %s "${_VW_DEFAULT_PUID}")}"
PGID="${PGID:-$(get_config_value PGID "${_VW_DEFAULT_PGID}" 2>/dev/null || printf %s "${_VW_DEFAULT_PGID}")}"
PUID="${PUID//$'\r'/}"; PUID="${PUID%%[[:space:]#]*}"; PUID="${PUID//[[:space:]]/}"
PGID="${PGID//$'\r'/}"; PGID="${PGID%%[[:space:]#]*}"; PGID="${PGID//[[:space:]]/}"
STATUS=0

_report_drift() {
    local path="$1" label="$2"
    log_error "$label permission drift: $path"
    log_error "Fix: sudo ./utilities/repair-permissions.sh"
    STATUS=1
}

_check_or_repair_known() {
    local path="$1" label="$2"
    [[ -e "$path" || -L "$path" ]] || return 0
    if assert_known_path_permissions "$path"; then
        log_info "Permission metadata is correct: $path"
        return 0
    fi
    if [[ "$MODE" == check ]]; then
        _report_drift "$path" "$label"
        return 0
    fi
    if ! fix_known_path_permissions "$path" || ! assert_known_path_permissions "$path"; then
        log_error "$label repair failed postcondition verification: $path"
        STATUS=1
        return 1
    fi
    log_success "Verified permission repair: $path"
}

_check_or_repair_not_world() {
    local path="$1" label="$2" mode mode_int new_mode
    [[ -e "$path" && ! -L "$path" ]] || return 0
    [[ -f "$path" || -d "$path" ]] || { log_error "$label has unsupported type: $path"; STATUS=1; return 1; }
    mode="$(stat -c '%a' "$path" 2>/dev/null || stat -f '%Lp' "$path" 2>/dev/null)" || { STATUS=1; return 1; }
    mode_int=$((8#$mode))
    (( (mode_int & 0007) == 0 )) && return 0
    if [[ "$MODE" == check ]]; then
        _report_drift "$path" "$label"
        return 0
    fi
    new_mode="$(printf '%03o' $((mode_int & 0770)))"
    chmod "$new_mode" -- "$path" || { STATUS=1; return 1; }
    mode="$(stat -c '%a' "$path" 2>/dev/null || stat -f '%Lp' "$path" 2>/dev/null)" || { STATUS=1; return 1; }
    (( (8#$mode & 0007) == 0 )) || { log_error "$label remains world-accessible: $path"; STATUS=1; return 1; }
    log_success "Verified world-access removal: $path"
}

for target in \
    "${PROJECT_ROOT}/.sops.yaml" \
    "${PROJECT_ROOT}/secrets/keys/age-key.txt" \
    /etc/vaultwarden \
    /etc/vaultwarden/age-key.txt \
    /etc/vaultwarden/vaultwarden.env \
    /etc/vaultwarden/rclone.conf \
    "${PROJECT_STATE_DIR}/config" \
    "${PROJECT_STATE_DIR}/config/install.env" \
    "${PROJECT_STATE_DIR}/config/dr-manifest.env" \
    "${PROJECT_STATE_DIR}/secrets" \
    "$SECRETS_FILE" \
    /run/vaultwarden-oci/managed-secrets \
    /run/vaultwarden-oci/secrets; do
    _check_or_repair_known "$target" "Known path"
done

if [[ -d /run/vaultwarden-oci/secrets && ! -L /run/vaultwarden-oci/secrets ]]; then
    runtime_secret_list="$(mktemp)" || { log_error "Could not create runtime-secret inventory."; exit 1; }
    if ! find /run/vaultwarden-oci/secrets -xdev -mindepth 1 -maxdepth 1 -print0 > "$runtime_secret_list"; then
        log_error "Could not enumerate runtime secret nodes."
        STATUS=1
    else
        while IFS= read -r -d '' target; do
            if [[ ! -f "$target" || -L "$target" ]]; then
                log_error "Runtime secret has unsupported type: $target"
                STATUS=1
                continue
            fi
            _check_or_repair_known "$target" "Runtime secret"
        done < "$runtime_secret_list"
    fi
    rm -f "$runtime_secret_list"
    runtime_secret_list=""
fi

if [[ "$MODE" == check ]]; then
    validate_runtime_state_permissions "$PROJECT_STATE_DIR" "$PUID" "$PGID" || STATUS=1
else
    repair_runtime_state_permissions "$PROJECT_STATE_DIR" "$PUID" "$PGID" || STATUS=1
fi

shopt -s nullglob
for target in "${PROJECT_ROOT}"/recovery-kit-*.txt "${PROJECT_ROOT}"/recovery-kit-*.zip "${PROJECT_ROOT}"/vaultwarden-recovery-kit-*; do
    _check_or_repair_not_world "$target" "Recovery kit"
done

if (( STATUS != 0 )); then
    log_error "Permission ${MODE} did not satisfy every required postcondition."
    exit 1
fi
log_success "Permission ${MODE} completed with verified postconditions."
