PR #280 completion candidate
Starting PR head: c3cb8c68dd6601eccdaeddd52f29cb369a76acfa
Target branch: codex/small-team-runtime-remediation

This bundle contains only the intended replacement files.
It does not contain a workflow, publisher, handoff, snapshot, or retrigger artifact.

Apply from the repository root only after verifying the current PR head is still the starting SHA:
  tar -xzf pr280-completion-candidate.tar.gz
  cp -a pr280-completion-candidate/. .

Then run the repository workflow commands and inspect the exact-final GitHub Actions run.
