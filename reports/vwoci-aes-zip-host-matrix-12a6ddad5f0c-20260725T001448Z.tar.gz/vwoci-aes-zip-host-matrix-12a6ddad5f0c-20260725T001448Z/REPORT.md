# VaultWarden-OCI AES-ZIP host matrix

Head: `12a6ddad5f0c0f3a6bbb21a10bf9bd235a441cf7`

This diagnostic is read-only and uses fixed synthetic passwords only.

## Files

- `source-context.txt`: exact helper and assertion context
- `archiver-versions.txt`: installed 7z/7zz versions
- `matrix-summary.tsv`: return codes for each transport
- `matrix/`: full sanitized command output
- `case-email-normal.txt`: current email security case
- `case-email-xtrace.txt`: sanitized xtrace

## Interpretation

The inline-password cases are synthetic baselines only. They are not a production recommendation.
A suitable production design must work with the installed binary while keeping real passwords out of argv and environment.
