# VaultWarden-OCI CI one-shot diagnostics

- Repository: `/workspaces/VaultWarden-OCI`
- Branch: `fix/production-readiness-handoffs`
- HEAD: `cd7f15f4cf734ede7af4cb42ecb05ddebd919ce6`
- GitHub Actions run: `30129277815`
- Generated UTC: `20260724T222056Z`

## Collection behavior

- No `.env`, encrypted secret store, recovery handoff, or private-key file content is collected.
- Focused tests run in a detached temporary worktree at the exact committed HEAD.
- Captured output is sanitized for common password, token, authorization, and Age-private-key patterns.
- Non-zero test results are recorded rather than causing the diagnostic script to abort.

## Non-zero diagnostic commands

- `suite-data-protection`
- `suite-security`
- `test-security-case`
- `trace-security-case`

## Missing optional tools

- `shellcheck-focused`
- `version-7z`
- `version-7za`
- `version-7zz`
- `version-shellcheck`

## Most relevant files

- `context-security-guard.txt`
- `trace-security-case.log`
- `context-data-protection-zip.txt`
- `trace-data-protection-case.log`
- `gh-run-failed.log`
- `summary.json`
